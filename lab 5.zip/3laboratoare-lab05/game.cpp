#include "game.hpp"
#include <iostream>
#include <sstream>
using namespace std;

Game::Game() : board(make_shared<Board>()), currentPlayer('X') {}

void Game::switchPlayer() {
    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
}

void Game::play() {
    int row, col;
    string input;
    char winner = ' ';

    cout << "Doriti sa incarcati un joc salvat? (y/n): ";
    getline(cin, input);
    if (input == "y" || input == "Y") {
        board->loadState("gamestate.json");
        cout << "Introduceti jucatorul curent (X/O): ";
        getline(cin, input);
        if (input == "X" || input == "x") {
            currentPlayer = 'X';
        } else if (input == "O" || input == "o") {
            currentPlayer = 'O';
        } else {
            cout << "Intrare invalida. Jucatorul implicit este X.\n";
            currentPlayer = 'X';
        }
    }

    while (true) {
        board->printBoard();

        cout << "Jucatorul " << currentPlayer << ", introdu coordonatele (rand si coloana) sau 's' pentru a salva: ";
        getline(cin, input);

        if (input == "s" || input == "S") {
            board->saveState("gamestate.json");
            cout << "Joc salvat.\n";
            continue;
        }

        istringstream iss(input);
        if (!(iss >> row >> col)) {
            cout << "Intrare invalida. Incercati din nou.\n";
            continue;
        }

        if (row < 0 || row > 2 || col < 0 || col > 2) {
            cout << "Coordonate in afara limitelor. Incercati din nou.\n";
            continue;
        }

        if (!board->markMove(row, col, currentPlayer)) {
            cout << "Mutare invalida. Incercati din nou.\n";
            continue;
        }

        winner = board->checkWin();
        if (winner != ' ') {
            board->printBoard();
            cout << "Jucatorul " << winner << " a castigat!\n";
            break;
        }

        if (board->isFull()) {
            board->printBoard();
            cout << "Jocul s-a terminat cu egalitate!\n";
            break;
        }

        switchPlayer();
    }
}
